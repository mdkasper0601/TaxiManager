﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaxiManagementAssignment
{
    public class Taxi
    {
        public int Number;
        public Taxi(int num)
        {
            Number = num;
        }
    }
}
